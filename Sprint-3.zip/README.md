# Sprint-3

Componentes:
- APIProxySetup
- SEMSProxySetup
- Weather
- Climate
- Integrations


