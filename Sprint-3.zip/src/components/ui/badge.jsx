export function Badge({ children, className }) {
  return (
    <span className={\`px-2 py-1 rounded-full bg-slate-700 text-slate-300 text-xs \${className}\`}>
      {children}
    </span>
  );
}