export function Input({ className, ...props }) {
  return (
    <input
      className={\`px-3 py-2 rounded-lg border border-slate-600 bg-slate-800 text-slate-200 \${className}\`}
      {...props}
    />
  );
}