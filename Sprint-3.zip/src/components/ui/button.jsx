export function Button({ children, className, onClick, variant = "default", size = "md", ...props }) {
  const base = "rounded-xl px-4 py-2 font-medium transition";
  const variants = {
    default: "bg-green-500 hover:bg-green-600 text-white",
    outline: "border border-slate-600 text-slate-300 hover:bg-slate-700"
  };
  const sizes = {
    sm: "text-sm px-2 py-1",
    md: "text-base"
  };
  return (
    <button
      onClick={onClick}
      className={\`\${base} \${variants[variant]} \${sizes[size]} \${className}\`}
      {...props}
    >
      {children}
    </button>
  );
}