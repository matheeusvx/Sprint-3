export default function ConfigBox() {
  return (
    <div className="bg-slate-700 text-white p-4 rounded-lg">
      <p>Configurações de Integração (placeholder).</p>
    </div>
  );
}