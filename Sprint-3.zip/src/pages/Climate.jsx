
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CloudSun, MapPin, LocateFixed, Loader2, Sun, CloudRain, Wind, Gauge } from "lucide-react";
import { InvokeLLM } from "@/integrations/Core";
import { WeatherData } from "@/entities/WeatherData";
import WeatherInsights from "@/components/weather/WeatherInsights";
import { User } from "@/entities/all";

// Fallback para garantir dados em qualquer erro
const DEFAULT_COORDS = { lat: -23.55, lon: -46.63 }; // São Paulo

export default function Climate() {
  const [coords, setCoords] = React.useState(null);
  const [place, setPlace] = React.useState("");
  const [query, setQuery] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [forecast, setForecast] = React.useState(null);
  const [insights, setInsights] = React.useState("");
  const [insightMeta, setInsightMeta] = React.useState({ title: "", priority: "Moderada", recommended: "" });
  const [errorMsg, setErrorMsg] = React.useState("");
  const [owKey, setOwKey] = React.useState("");

  // NEW: load OpenWeather key from user
  React.useEffect(() => {
    (async () => {
      const u = await User.me().catch(() => null);
      setOwKey(u?.openweather_api_key || "");
    })();
  }, []);

  const makeInsights = React.useCallback(async (wx) => {
    const daily = wx?.daily;
    const summary = {
      today: {
        tmax: daily?.temperature_2m_max?.[0],
        tmin: daily?.temperature_2m_min?.[0],
        rain_mm: daily?.precipitation_sum?.[0],
        sunrise: daily?.sunrise?.[0],
        sunset: daily?.sunset?.[0],
      },
      hints: {
        clouds_mean_12h: wx?.hourly?.cloudcover?.slice(10, 22)?.reduce((a, b) => a + b, 0) / 12,