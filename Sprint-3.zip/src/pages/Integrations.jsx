
import React from "react";
import ConfigBox from "@/components/integrations/ConfigBox";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Integrations() {
  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-5xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Integrações de Dados</h1>
          <p className="text-slate-400">Conecte uma API, arquivo CSV/JSON ou seu proxy GoodWe SEMS e importe dados para o app.</p>
        </div>
        <ConfigBox />
        <Card className="bg-slate-800/40 border-slate-700">
          <CardContent className="text-slate-400 text-sm p-4">
            Dica: para GoodWe, use nosso guia em “Backend SEMS Proxy (FastAPI)” no menu e aponte o Base URL aqui.
          </CardContent>
        </Card>
        <Card className="bg-slate-800/40 border-slate-700">
          <CardContent className="text-slate-300 text-sm p-4 flex items-center justify-between gap-3 flex-col md:flex-row">
            <div className="text-center md:text-left">
              Está enfrentando CORS em APIs públicas (Solcast, NREL, Forecast.Solar)? Use o nosso “Proxy Universal de API” para executar chamadas no backend.
            </div>
            <Link to={createPageUrl("APIProxySetup")}>
              <Button className="bg-gradient-to-r from-green-500 to-blue-500">Abrir guia do Proxy</Button>
            </Link>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/40 border-slate-700">
          <CardContent className="text-slate-300 text-sm p-4 flex items-center justify-between gap-3 flex-col md:flex-row">
            <div className="text-center md:text-left">
              Após importar para a entidade EnergyData, visualize imediatamente no Painel de Energia.
            </div>
            <Link to={createPageUrl("Dashboard")}>
              <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">Ver no Painel</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}