import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Server, Cloud, Globe, Shield, Link as LinkIcon } from "lucide-react";
import { createPageUrl } from "@/utils";

const Section = ({ title, icon: Icon, children }) => (
  <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
    <CardHeader>
      <CardTitle className="text-white text-base flex items-center gap-2">
        <Icon className="w-4 h-4 text-green-400" /> {title}
      </CardTitle>
    </CardHeader>
    <CardContent>{children}</CardContent>
  </Card>
);

const CodeBlock = ({ filename, content }) => {
  const copy = async () => {
    await navigator.clipboard.writeText(content.trim());
  };
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <div className="text-slate-300 text-xs">{filename}</div>
        <Button size="sm" variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700" onClick={copy}>
          <Copy className="w-4 h-4 mr-2" /> Copiar
        </Button>
      </div>
      <pre className="text-xs text-slate-200 bg-slate-900 border border-slate-700 rounded-lg p-3 overflow-auto whitespace-pre">
{content}
      </pre>
    </div>
  );
};

export default function APIProxySetup() {
  const expressProxy = `
/*
  Proxy Universal FIXO (um provedor por deploy)
  - Define TARGET_BASE (ex.: https://api.solcast.com.au ou https://api.forecast.solar)
  - Encaminha /proxy/* -> TARGET_BASE/*
  - Preserva Authorization e headers customizados
  - Suporta GET, POST, PUT, DELETE
  - Respeita CORS para o domínio do app (ALLOWED_ORIGINS)
  - Node 18+ (fetch nativo)
*/
import express from "express";
import cors from "cors";

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));

const TARGET_BASE = process.env.TARGET_BASE; // ex.: https://api.forecast.solar
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "*").split(",").map(s => s.trim());

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || ALLOWED_ORIGINS.includes("*") || ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
    return cb(new Error("Not allowed by CORS"));
  },
  credentials: true,
  allowedHeaders: ["Content-Type", "Authorization", "X-Api-Key", "X-Requested-With", "Accept"]
}));

const allowedMethods = new Set(["GET", "POST", "PUT", "DELETE", "PATCH"]);

app.all("/proxy/*", async (req, res) => {
  try {
    if (!TARGET_BASE) return res.status(500).json({ error: "Missing TARGET_BASE env" });
    const method = (req.method || "GET").toUpperCase();
    if (!allowedMethods.has(method)) return res.status(405).json({ error: "Method Not Allowed" });

    const subPath = req.originalUrl.replace(/^\\/proxy/, "");
    const url = new URL(subPath, TARGET_BASE).toString();

    // Sanitiza e preserva cabeçalhos importantes
    const outHeaders = {};
    const incoming = req.headers || {};
    const passHeaders = ["authorization", "x-api-key", "content-type", "accept"];
    for (const k of passHeaders) {
      if (incoming[k]) outHeaders[k] = incoming[k];
    }

    const hasBody = !["GET", "HEAD"].includes(method);
    const body = hasBody ? (req.is("application/json") ? JSON.stringify(req.body || {}) : undefined) : undefined;

    const upstream = await fetch(url, {
      method,
      headers: outHeaders,
      body
    });

    const contentType = upstream.headers.get("content-type") || "";
    const status = upstream.status;

    if (contentType.includes("application/json")) {
      const json = await upstream.json().catch(() => ({}));
      return res.status(status).json(json);
    } else {
      const text = await upstream.text().catch(() => "");
      res.setHeader("content-type", contentType || "text/plain; charset=utf-8");
      return res.status(status).send(text);
    }
  } catch (e) {
    const msg = e?.message || "Failed to fetch";
    // Diferencia alguns erros comuns
    if (/unauthorized|401/i.test(msg)) return res.status(401).json({ error: "Unauthorized", details: msg });
    if (/not found|404/i.test(msg)) return res.status(404).json({ error: "Not Found", details: msg });
    return res.status(502).json({ error: "Bad Gateway", details: msg });
  }
});

const port = process.env.PORT || 8080;
app.listen(port, () => {
  console.log("API proxy listening on port", port);
});
  `.trim();

  const workerProxy = `
/*
  Cloudflare Worker: Proxy fixo (TARGET_BASE)
  - Defina TARGET_BASE em Vars
  - Encaminha /proxy/* -> TARGET_BASE/*
*/
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/proxy/")) {
      return new Response("OK", { status: 200 });
    }

    const targetBase = env.TARGET_BASE; // ex.: https://api.solcast.com.au
    if (!targetBase) return new Response(JSON.stringify({ error: "Missing TARGET_BASE" }), { status: 500 });

    const subPath = url.pathname.replace(/^\\/proxy/, "");
    const targetUrl = new URL(subPath, targetBase).toString();

    const passHeaders = new Headers();
    const incoming = request.headers;
    ["authorization", "x-api-key", "content-type", "accept"].forEach(h => {
      const v = incoming.get(h);
      if (v) passHeaders.set(h, v);
    });

    const init = {
      method: request.method,
      headers: passHeaders
    };

    if (!["GET", "HEAD"].includes(request.method)) {
      init.body = await request.arrayBuffer();
    }

    const upstream = await fetch(targetUrl, init);
    const newHeaders = new Headers(upstream.headers);
    // CORS
    newHeaders.set("Access-Control-Allow-Origin", env.ALLOWED_ORIGINS || "*");
    newHeaders.set("Vary", "Origin");

    return new Response(upstream.body, { status: upstream.status, headers: newHeaders });
  }
};
  `.trim();

  const vercelEdge = `
/*
  Vercel Edge Function (proxy fixo) - /api/proxy/*
  - Em vercel.json, aponte para runtime edge
  - Defina TARGET_BASE como variável de ambiente
*/
export const config = { runtime: "edge" };

export default async function handler(req) {
  const { NEXT_PUBLIC_ALLOWED_ORIGINS, TARGET_BASE } = process.env;
  if (!TARGET_BASE) {
    return new Response(JSON.stringify({ error: "Missing TARGET_BASE" }), { status: 500, headers: { "content-type": "application/json" } });
  }

  const url = new URL(req.url);
  const subPath = url.pathname.replace(/^\\/api\\/proxy/, "");
  const targetUrl = new URL(subPath, TARGET_BASE).toString();

  const passHeaders = new Headers();
  req.headers.forEach((v, k) => {
    if (["authorization", "x-api-key", "content-type", "accept"].includes(k)) passHeaders.set(k, v);
  });

  const init = { method: req.method, headers: passHeaders };
  if (!["GET", "HEAD"].includes(req.method)) {
    const body = await req.arrayBuffer();
    init.body = body;
  }

  const upstream = await fetch(targetUrl, init);
  const headers = new Headers(upstream.headers);
  headers.set("Access-Control-Allow-Origin", NEXT_PUBLIC_ALLOWED_ORIGINS || "*");
  headers.set("Vary", "Origin");

  return new Response(upstream.body, { status: upstream.status, headers });
}
  `.trim();

  const howToUse = `
Como usar com o Conector de Integrações (sem CORS no navegador):
1) Faça o deploy de UM dos proxies acima.
2) Defina TARGET_BASE para o provedor desejado (ex.: https://api.forecast.solar ou https://developer.nrel.gov).
3) No Base44 > Integrações:
   - Tipo de Fonte: API REST
   - Base URL: https://SEU-PROXY (ex.: https://proxy-minhaapp.vercel.app)
   - Endpoint: /proxy/RotaOriginalDoProvedor (ex.: /proxy/estimate/watts/50.0/-1.0/15/10)
   - Método: GET (ou POST/PUT/DELETE conforme a API)
   - Authorization / headers: configure normalmente (Bearer/Api-Key), o proxy preserva e repassa.
4) Clique “Testar Conexão” e depois mapeie os campos normalmente.

Erros no backend serão propagados (401, 404, 5xx) para facilitar o debug.
  `.trim();

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-white flex items-center gap-2">
            <Globe className="w-7 h-7 text-green-400" />
            Proxy Universal de API (Server-side)
          </h1>
          <a href={createPageUrl("Integrations")}>
            <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
              <LinkIcon className="w-4 h-4 mr-2" /> Ir para Integrações
            </Button>
          </a>
        </div>

        <p className="text-slate-300">
          Use um proxy server-side para contornar CORS e consumir APIs reais (Solcast, NREL, Forecast.Solar, etc.).
          O proxy abaixo preserva Authorization e métodos HTTP, retornando JSON bruto para o conector.
        </p>

        <Section title="Express (Node 18+ / Docker / Render / Railway / ECS)" icon={Server}>
          <CodeBlock filename="server.js" content={expressProxy} />
          <CodeBlock filename=".env" content={`TARGET_BASE=https://api.forecast.solar\nALLOWED_ORIGINS=https://seu-app.base44.app`} />
          <p className="text-slate-400 text-sm">Dica: Rode em Node 18+ e exponha porta 8080 (ou defina PORT).</p>
        </Section>

        <Section title="Cloudflare Worker (Edge)" icon={Cloud}>
          <CodeBlock filename="worker.js" content={workerProxy} />
          <CodeBlock filename="Wrangler Vars" content={`TARGET_BASE=https://api.solcast.com.au\nALLOWED_ORIGINS=https://seu-app.base44.app`} />
        </Section>

        <Section title="Vercel Edge Function" icon={Shield}>
          <CodeBlock filename="api/proxy.js" content={vercelEdge} />
          <CodeBlock filename="Env" content={`TARGET_BASE=https://developer.nrel.gov\nNEXT_PUBLIC_ALLOWED_ORIGINS=https://seu-app.base44.app`} />
        </Section>

        <Section title="Como configurar no Base44 (passo a passo)" icon={Globe}>
          <CodeBlock filename="Passos" content={howToUse} />
        </Section>
      </div>
    </div>
  );
}