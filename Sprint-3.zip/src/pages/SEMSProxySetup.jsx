import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Server, Terminal, FileCode, Shield, Link as LinkIcon } from "lucide-react";

const Section = ({ title, children, icon: Icon = FileCode }) => (
  <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur-sm">
    <CardHeader className="flex items-center justify-between">
      <CardTitle className="text-white text-base flex items-center gap-2">
        <Icon className="w-4 h-4 text-green-400" /> {title}
      </CardTitle>
    </CardHeader>
    <CardContent>{children}</CardContent>
  </Card>
);

const CodeBlock = ({ filename, content }) => {
  const copy = async () => {
    await navigator.clipboard.writeText(content.trim());
  };
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <div className="text-slate-300 text-xs">{filename}</div>
        <Button size="sm" variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700" onClick={copy}>
          <Copy className="w-4 h-4 mr-2" /> Copiar
        </Button>
      </div>
      <pre className="text-xs text-slate-200 bg-slate-900 border border-slate-700 rounded-lg p-3 overflow-auto whitespace-pre">
{content}
      </pre>
    </div>
  );
};

export default function SEMSProxySetup() {
  const requirements = `
fastapi
uvicorn[standard]
aiohttp
sems-portal-api==0.1.1
python-dotenv
cachetools
pytest
pytest-asyncio
httpx