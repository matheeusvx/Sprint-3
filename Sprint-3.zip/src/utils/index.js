export function createPageUrl(page) {
  return \`/${page}\`;
}